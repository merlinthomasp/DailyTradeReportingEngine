package com.report.manager;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.report.bean.BuySell;
import com.report.bean.MarketData;

public class ReportingManager {
	
	private DateManager dateManager = new DateManager();
	
	private final static Logger logger = Logger.getLogger(ReportingManager.class);
	
	public void processMarketData(List<MarketData> marketDataList){
		List<MarketData> incomingMarketReport = new ArrayList<MarketData>();
		List<MarketData> outgoingMarketReport = new ArrayList<MarketData>();
		
		try{
			for(int i=0; i< marketDataList.size(); i++){
				MarketData marketData = marketDataList.get(i);
				
				// Check if it is a working day
				boolean isWorkingDay = dateManager.checkIfWorkingDay(marketData.getSettlementDate(), marketData.getCurrency());
				
				// If it is a working day, calculate the USD Amount of Trade
				if(isWorkingDay){
					// USD amount of a trade = Price per unit * Units * Agreed Fx
					BigDecimal unitPrice = marketData.getPricePerUnit().multiply(marketData.getUnits());
					BigDecimal usdAmount = unitPrice.multiply(marketData.getAgreedFx());
					marketData.setUsdAmount(usdAmount);
					
					// If it is a Sell, then it is an Amount in USD settled incoming
					if(marketData.getBuySell().equalsIgnoreCase(BuySell.SELL.getValue())){
						incomingMarketReport.add(marketData);
					}
					// If it is a B- Buy, then it is an Amount in USD settled outgoing
					else if(marketData.getBuySell().equalsIgnoreCase(BuySell.BUY.getValue())){
						outgoingMarketReport.add(marketData);
					}	
				}else{
					// If an instructed settlement date is not a working day, then the settlement date is changed to the next working day 
					 String newSettlementDate = dateManager.calculatetNextSettlementDate(marketData.getSettlementDate(), marketData.getCurrency());
					 marketData.setSettlementDate(newSettlementDate);
				}
			}
			// Prints the Incoming and Outgoing Reports in Console
			printIncomingOutgoingReports(incomingMarketReport, outgoingMarketReport);	
			
		}catch(Exception e){
			logger.error(this.getClass() + " Error in executing processMarketData() " + e.getMessage()); 
		}
	}
			
	private void printIncomingOutgoingReports(List<MarketData> incomingMarketReport, List<MarketData> outgoingMarketReport){
		// Printing Incoming Reports
		System.out.println("*************** Incoming Reports Starts *******************");
		for(int i = 0; i < incomingMarketReport.size(); i++){
			System.out.println("Buy Sell = " + incomingMarketReport.get(i).getBuySell());
			System.out.println("Entity = " + incomingMarketReport.get(i).getEntity());
			System.out.println("USD Amount = " + incomingMarketReport.get(i).getUsdAmount());
		}
		System.out.println("Highest Rank of Incoming Report --> Entity : " + calculateRankForReports(incomingMarketReport));
		System.out.println("*************** End of Incoming Reports  *******************");

		// Printing Outgoing Reports
		System.out.println("*************** Outgoing Reports Starts *******************");
		for(int i = 0; i < outgoingMarketReport.size(); i++){
			System.out.println("Buy Sell = " + outgoingMarketReport.get(i).getBuySell());
			System.out.println("Entity = " + outgoingMarketReport.get(i).getEntity());
			System.out.println("USD Amount = " + outgoingMarketReport.get(i).getUsdAmount());
		}
		System.out.println("Highest Rank of Outgoing Report --> Entity : " + calculateRankForReports(outgoingMarketReport));
		System.out.println("*************** End of Outgoing Reports  *******************");
	}
	
	
	// Calculates the Entity which has the highest Rank for the Incoming and Outgoing Reports
	private String calculateRankForReports(List<MarketData> marketReportList){
		BigDecimal greaterValue = new BigDecimal("0");
		int greatestValueIndex = 0;
		for(int i = 0; i < marketReportList.size(); i++){
			// Check if current value is greater than the "greaterValue"
		    if((marketReportList.get(i).getUsdAmount()).compareTo(greaterValue) == 1){
		    	 greaterValue = marketReportList.get(i).getUsdAmount();	
		    	 greatestValueIndex = i;
		    }
		}
		return marketReportList.get(greatestValueIndex).getEntity();
	}
}
