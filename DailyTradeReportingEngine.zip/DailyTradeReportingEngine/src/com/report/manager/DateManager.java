package com.report.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import com.report.util.DateUtil;

public class DateManager {
	
	private DateUtil dateUtil = new DateUtil();
	private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd MMM yyyy");
	
	private final static Logger logger = Logger.getLogger(DateManager.class);
	
	// Checks if Settlement Date is a working day
	public boolean checkIfWorkingDay(String settlementDate, String currency){
		boolean isWorkingDay = false;
		try{
			// Format Settlement Date
		    Date formattedSettlementDate = dateUtil.formatDates(settlementDate);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(formattedSettlementDate);
			
			// If currency of the trade is AED or SAR, the working week starts from Sunday and ends Thursday.
			if((currency.equalsIgnoreCase("AED")) || (currency.equalsIgnoreCase("SAR"))){
				isWorkingDay = IsArabianWorkingDay(calendar);
			}else{
				isWorkingDay = isNonArabianWorkingDay(calendar);
			}
	    } catch (ParseException e) {
	    	logger.error(this.getClass() + " Error in executing checkIfWorkingDay() " + e.getMessage()); 
		}
		return isWorkingDay;
	}
	
	// Calculates the Next working settlement date
	public String calculatetNextSettlementDate(String settlementDate, String currency){
		String formatSettlementDate = "";
		Calendar calendar = Calendar.getInstance();
		try{
			// Format Settlement Date
		    Date formattedSettlementDate = dateUtil.formatDates(settlementDate);
			calendar.setTime(formattedSettlementDate);
			
			// Gets the day difference for the next working day
			int days = calculatetNextWorkingDay(calendar, currency);
			
			// Add the days to the settlement date to get the next working date
			calendar.add(Calendar.DATE, days);
			Date newSettlementDate = calendar.getTime();
			formatSettlementDate = simpleDateFormat.format(newSettlementDate);
	    } catch (ParseException e) {
	    	logger.error(this.getClass() + " Error in executing calculatetNextSettlementDate() " + e.getMessage()); 
		}
		return formatSettlementDate;
	}
	
	// Gets the day difference for the next working day
	private int calculatetNextWorkingDay(Calendar calendar, String currency){
		int days = 0;
		if((currency.equalsIgnoreCase("AED")) || (currency.equalsIgnoreCase("SAR"))){
			// If it is FRIDAY, then 2 days should be added to the settlement date to get the next working date
			if(calendar.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY){
				days = 2;
			}
			// If it is FRIDAY, then 1 day should be added to the settlement date to get the next working date
			else if(calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY){
				days = 1;
			}
		}else{
			// If it is SATURDAY, then 2 days should be added to the settlement date to get the next working date
			if(calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY){
				days = 2;
			}
			// If it is SUNDAY, then 1 day should be added to the settlement date to get the next working date
			else if(calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY){
				days = 1;
			}
		}
		return days;
	}
	
	// Checks if it is working day for Arabians
	public boolean IsArabianWorkingDay(Calendar calendar){
		// If currency of the trade is AED or SAR, the working week starts from Sunday and ends Thursday.
		if(calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY || calendar.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY 
					|| calendar.get(Calendar.DAY_OF_WEEK) == Calendar.TUESDAY || calendar.get(Calendar.DAY_OF_WEEK) == Calendar.WEDNESDAY
					|| calendar.get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY){
				return true;
		}else{
			return false;
		}
	}
	
	// Checks if it is working day for Non-Arabians
	public boolean isNonArabianWorkingDay(Calendar calendar){
		// If currency of the trade is not AED or SAR, then the working week starts from Monday and ends Friday.
		if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY || calendar.get(Calendar.DAY_OF_WEEK) == Calendar.TUESDAY 
				|| calendar.get(Calendar.DAY_OF_WEEK) == Calendar.WEDNESDAY || calendar.get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY
				|| calendar.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY){
			return true;
		}else{
			return false;
		}
	}
		
	// Adds the days to the calendar
    public static Date addDays(Date d, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        cal.add(Calendar.DATE, days);
        return cal.getTime();
    }
}
