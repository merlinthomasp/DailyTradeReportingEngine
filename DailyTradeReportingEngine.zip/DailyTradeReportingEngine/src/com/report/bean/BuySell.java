package com.report.bean;

public enum BuySell {
	BUY("B"), 
	SELL("S");
	
	private final String value;

	private BuySell(String value) {
		  this.value = value;
	}

	public String getValue() {
		return this.value;
	}  
}

