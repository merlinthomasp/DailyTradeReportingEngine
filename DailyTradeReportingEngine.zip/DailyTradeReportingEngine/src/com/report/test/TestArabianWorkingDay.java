package com.report.test;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.report.manager.DateManager;
import com.report.util.DateUtil;

public class TestArabianWorkingDay {
	
	private String settlementDate;
	
	private DateUtil dateUtil = new DateUtil();
	private DateManager dateManager = new DateManager();
	
	public TestArabianWorkingDay() {
	}

	@Before
	public void setUp() throws Exception {
		settlementDate = "14 Jun 2017";
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		boolean result = true;
		try {
			 Date formattedSettlementDate = dateUtil.formatDates(settlementDate);
			 
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(formattedSettlementDate);
			
			boolean isWorkingDayForArabians = dateManager.IsArabianWorkingDay(calendar);
			
			assertEquals(isWorkingDayForArabians, result);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

}
