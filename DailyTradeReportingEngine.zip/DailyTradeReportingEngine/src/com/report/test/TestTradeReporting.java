package com.report.test;
import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.report.bean.MarketData;
import com.report.manager.ReportingManager;

public class TestTradeReporting extends TestCase{
	
	private ReportingManager reportingManager = new ReportingManager();
	private List<MarketData> tradeMarketList = new ArrayList<MarketData>();

	public TestTradeReporting() {
	}

	@Before
	public void setUp() throws Exception {
		tradeMarketList = new ArrayList<MarketData>();
		MarketData marketData = new MarketData();
		marketData.setEntity("foo");
		marketData.setBuySell("B");
		marketData.setAgreedFx(new BigDecimal("0.50"));
		marketData.setCurrency("SGP");
		marketData.setInstructionDate("01 Jun 2016");
		marketData.setSettlementDate("02 Jun 2016");
		marketData.setUnits(new BigDecimal("200"));
		marketData.setPricePerUnit(new BigDecimal("100.25"));
		tradeMarketList.add(marketData);
		
		MarketData marketData1 = new MarketData();
		marketData1.setEntity("bar");
		marketData1.setBuySell("S");
		marketData1.setAgreedFx(new BigDecimal("0.22"));
		marketData1.setCurrency("AED");
		marketData1.setInstructionDate("05 Jun 2016");
		marketData1.setSettlementDate("07 Jun 2016");
		marketData1.setUnits(new BigDecimal("450"));
		marketData1.setPricePerUnit(new BigDecimal("150.5"));
		tradeMarketList.add(marketData1);
		
		
		MarketData marketData2 = new MarketData();
		marketData2.setEntity("hotel");
		marketData2.setBuySell("B");
		marketData2.setAgreedFx(new BigDecimal("0.33"));
		marketData2.setCurrency("EUR");
		marketData2.setInstructionDate("10 Jun 2017");
		marketData2.setSettlementDate("12 Jun 2017");
		marketData2.setUnits(new BigDecimal("300"));
		marketData2.setPricePerUnit(new BigDecimal("200.25"));
		tradeMarketList.add(marketData2);
		
		MarketData marketData3 = new MarketData();
		marketData3.setEntity("foobar");
		marketData3.setBuySell("S");
		marketData3.setAgreedFx(new BigDecimal("0.66"));
		marketData3.setCurrency("SGP");
		marketData3.setInstructionDate("15 Jun 2016");
		marketData3.setSettlementDate("17 Jun 2016");
		marketData3.setUnits(new BigDecimal("200"));
		marketData3.setPricePerUnit(new BigDecimal("240.25"));
		tradeMarketList.add(marketData3);
		
		MarketData marketData4 = new MarketData();
		marketData4.setEntity("foobar");
		marketData4.setBuySell("S");
		marketData4.setAgreedFx(new BigDecimal("0.99"));
		marketData4.setCurrency("SAR");
		marketData4.setInstructionDate("23 Jun 2016");
		marketData4.setSettlementDate("24 Jun 2016");
		marketData4.setUnits(new BigDecimal("250"));
		marketData4.setPricePerUnit(new BigDecimal("300.25"));
		tradeMarketList.add(marketData4);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		// Calculates the INCOMING & OUTGOING Reports
		reportingManager.processMarketData(tradeMarketList);
		fail("Not yet implemented");
	}

}
