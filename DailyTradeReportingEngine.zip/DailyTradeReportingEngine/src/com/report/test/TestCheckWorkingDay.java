package com.report.test;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.report.manager.DateManager;

public class TestCheckWorkingDay extends TestCase{
	
	private String currency = "";
	private String settlementDate = "";
	
	private DateManager dateManager = new DateManager();

	public TestCheckWorkingDay() {
	}

	@Before
	public void setUp() throws Exception {
		currency = "SGP";
		settlementDate = "16 Jun 2017";
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		boolean result = true;
		boolean isWorkingDay = dateManager.checkIfWorkingDay(settlementDate, currency);
		assertEquals(isWorkingDay, result);
	}
	 
}
