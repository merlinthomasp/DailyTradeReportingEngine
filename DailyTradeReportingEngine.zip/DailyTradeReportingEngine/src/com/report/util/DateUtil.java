package com.report.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	
	private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd MMM yyyy");
	private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy, MM, dd");

	// Converts the dates
	public Date formatDates(String dateToFormat) throws ParseException{
		Date formattedDate = simpleDateFormat.parse(dateToFormat);
	    String formatedDateString = dateFormat.format(formattedDate);
	    return dateFormat.parse(formatedDateString);
	}

}
